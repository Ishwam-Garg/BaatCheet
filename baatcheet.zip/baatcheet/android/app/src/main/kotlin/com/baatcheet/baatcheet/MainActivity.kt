package com.baatcheet.baatcheet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
